/*
   Integralzone  积分专区
*/
import React, { Component } from 'react';
import styles from './Integralzone.css'
import { CarouselTool } from '../Tool/ToolRouter'
import graysearch from '../image/graysearch.png'
import headerback from '../image/headerback.png'
import zone1 from '../image/zone1.png'
import zone2 from '../image/zone2.png'
import zone3 from '../image/zone3.png'
import zone4 from '../image/zone4.png'
import item1 from '../image/item1.png'
import item2 from '../image/item2.png'
import item3 from '../image/item3.png'
import Selectedgoods from '../integralShop/Tool/Selectedgoods/Selectedgoods'
import creatHistory from 'history/createHashHistory'

class Integralzone extends Component {


    constructor(props) {
        super(props);

        this.state = {
            demo: [{ data: 1 }, { data: 1 }, { data: 1 }, { data: 1 }, { data: 1 },]
        };
    }
    componentDidMount() {
        document.title = "积分专区"

    }

    toDetailSearch = (value) => {
        this.props.history.push({ pathname: 'zoneSearch'})
        

    }
    ToClassification = (value) => {
        this.props.history.push({ pathname: 'PreferentialClassification'})
        

    }
    ToClassification = (value) => {
        this.props.history.push({ pathname: 'PreferentialClassification'})
        

    }
    ToZoneClassification = (value) => {
        this.props.history.push({ pathname: 'ZoneClassification'})
        

    }
    ToHotZone = (value) => {
        this.props.history.push({ pathname: 'HotZone'})
    }

    ToSureOeder(item) {
        this.props.history.push({ pathname: 'SureOeder',state: { item: item }})
    }
    backAction= () =>{
        const history = creatHistory();

        history.goBack();
   
    }

    render() {
        return (
            <div>
                {/* 顶部搜索 */}
                
                {/* 轮播图 */}
                <div className={styles.xuanfu}>
                <div className={styles.search} >
                    <img src={headerback} className={styles.searchImag} onClick={this.backAction}></img>
                    <div className={styles.searchBar} onClick={this.toDetailSearch}>
                        <img src={graysearch} className={styles.searchToolImag}></img>
                        <div className={styles.searchtitleserch}>

                            搜索商家名称/商品
                    </div>
                    </div>
                </div>
                    <CarouselTool bannerImage={this.state.bannerImage}></CarouselTool>
                </div>
                {/* 菜单 */}
                <div className={styles.menuDiv}>
                    <div className={styles.menuDivItem} onClick={this.ToClassification}>
                        <img className={styles.menuDivItemImage} src={zone1}></img>
                        <div className={styles.menuDivItemTitle}>优惠分类</div>
                    </div>
                    <div className={styles.menuDivItem} onClick={this.ToZoneClassification}>
                        <img className={styles.menuDivItemImage} src={zone2} ></img>
                        <div className={styles.menuDivItemTitle}>品牌分类</div>
                    </div>
                    <div className={styles.menuDivItem} onClick={this.ToHotZone}>
                        <img className={styles.menuDivItemImage} src={zone3}></img>
                        <div className={styles.menuDivItemTitle}>热兑排行</div>
                    </div>
                    <div className={styles.menuDivItem}>
                        <img className={styles.menuDivItemImage} src={zone4}></img>
                        <div className={styles.menuDivItemTitle}>积分抽奖</div>
                    </div>
                </div>

                <div className={styles.menuDiv2}>
                    <div className={styles.menuDivDetail}>
                     <img src={item1} className={styles.menuDiv2Left}></img>
                    </div>
                    <div className={styles.menuDivDetail}>
                    <img src={item2} className={styles.menuDiv2Right}></img>
                    <img src={item3} className={styles.menuDiv2Right}></img>
                    </div>
                </div>

                <ul className={styles.listul}>
                    {
                        this.state.demo.map((item) =>
                            <div className={styles.listItem} onClick={this.ToDiscountDetail}  onClick={this.ToSureOeder.bind(this,item)} >
                                <Selectedgoods></Selectedgoods>
                            </div>
                        )
                    }
                </ul>
                {/* 列表 */}
            </div>
        );
    }

}

export default Integralzone;



